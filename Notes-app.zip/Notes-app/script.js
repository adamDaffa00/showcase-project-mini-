const menu = document.querySelector('.menu');
const textfield = document.querySelector('.modal-field-section');
const emptyList = document.querySelector('.empty-list');
const noteList = document.querySelector('.list-note');
const container = document.querySelector('.container');
const trashPage = document.querySelector('#trash-page');
let noteAdded = false,titleInput,textareaInput,titleNoteValue,contentNoteValue;


// listener
trashPage.addEventListener('click', (e) => {
  window.location = 'recycle-bin.html';
});

// toggle menu function
function showMenu(e){
  menu.classList.toggle('toggle-menu');
}

// auto resize text area 
function addAutoResize() {
  document.querySelectorAll('[data-autoresize]').forEach(function (element) {
    element.style.boxSizing = 'border-box';
    var offset = element.offsetHeight - element.clientHeight;
    element.addEventListener('input', function (event) {
      event.target.style.height = 'auto';
      event.target.style.height = event.target.scrollHeight + offset + 'px';
    });
    element.removeAttribute('data-autoresize');
  });
}
addAutoResize();

// show field text
function showTextField(){
  if(!noteAdded)
    textfield.classList.add('show-modal');
    noteAdded = true;
}
// note class
class Note {
  constructor(title, content){
    this.title = title;
    this.content = content;
  }
}

function displayNoteList(){
  let noteObj = getNote();
  noteObj.forEach(note => addNoteList(note));
}

function addNoteList(note){
  const uList = noteList.querySelector('ul');
  
  //if(noteAdded){
    // tampilkan wadah list dan sembunyikan list kosong
    emptyList.classList.add('hide-empty-list');
    noteList.classList.remove('hide-list-note');
    // tampilkan list ke wadah
    uList.innerHTML += `
      <li>
        <h2> <a href="#" class="note-items"> ${note.title} </a></h2>
        <p> ${note.content} </p>
        <button class="read-note"> selengkapnya <i class="fas fa-arrow-right"> </i></button>
        <div class="edit-note">
          <button> <i class="fas fa-trash"></i></button>
        </div>
      </li>
    `;
//}
 // clearFieldText(note);
}

// local storage for note
function getNote(){
  let notes;
  if(localStorage.getItem('note') == null){
    notes = [];
  }else{
    notes = JSON.parse(localStorage.getItem('note'));
  }
  return notes;
}

function addLocalNotes(note){
  const notes = getNote();
  notes.push(note);
  localStorage.setItem('note',JSON.stringify(notes));
}

function removeNote(title){
  let notes = getNote();
  notes.forEach((item,index) => {
    if(title == item.title ){
      notes.splice(index,1);
    }
  });
  localStorage.setItem('note',JSON.stringify(notes));
}

// local storage for junk notes
function getJunkNotes(){
  let junkNotes;
  if(localStorage.getItem('junk-note') == null){
    junkNotes = [];
  }else{
    junkNotes = JSON.parse(localStorage.getItem('junk-note'));
  }
  return junkNotes;
}
function addLocalJunkNotes(junkNote){
  let junkNotes = getJunkNotes();
  junkNotes.push(junkNote);
  localStorage.setItem('junk-note',JSON.stringify(junkNotes));
}

// render localNote
document.addEventListener('DOMContentLoaded',displayNoteList);
// menambahkan catatan ke dalam list
function addNote(){
   titleInput = document.getElementById('title');
   textareaInput = document.getElementById('textarea');
  const trashBtn = document.getElementById('clear');
  // cek apakah field text kosong 
  if (titleInput.value.length != 0) {
    if(textareaInput.value == ''){
      alert('anda belum mengisi catatan');
    }
    else{
     // block kode 
     const newNote = new Note(titleInput.value,textareaInput.value);
     trashBtn.addEventListener('click',() => {
       clearFieldText(titleInput,textareaInput);
     });
     addLocalNotes(newNote);
     addNoteList(newNote);
     clearFieldText();
    }
  }else{
    alert('anda belum mengisi judul');
  }
}

function clearFieldText(){
  if (noteAdded) {
   titleInput.value = '';
   textareaInput.value = '';
  }
}

// Fungsi untuk tombol cancel pada tedt field
function cancel(e){
  if(noteAdded){
     e.target.parentElement.parentElement.parentElement.parentElement.classList.remove('show-modal');
  }
  noteAdded = false;
}

// fungsi untuk menghilangkan modal catatan
function closeModalNote(e){
  e.target.parentElement.parentElement.parentElement.classList.remove('show-modal');
}


noteList.addEventListener('click',(e) => {
  if(e.target.classList.contains('fa-trash')){
    titleNoteValue = e.target.parentElement.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.innerText;
    contentNoteValue = e.target.parentElement.parentElement.previousElementSibling.previousElementSibling.innerText;
    removeNote(titleNoteValue);
    let myJunkNote = new Note(titleNoteValue,contentNoteValue);
    addLocalJunkNotes(myJunkNote);
    e.target.parentElement.parentElement.parentElement.classList.add('delete-list');
  }
  else if(e.target.classList.contains('read-note')){
    titleNoteValue = e.target.previousElementSibling.previousElementSibling.innerText;
    contentNoteValue = e.target.previousElementSibling.innerText;
    renderModalNote(titleNoteValue,contentNoteValue);
  }
});


function renderModalNote(title,text){
  const modalSection = document.createElement('section');
  modalSection.classList.add('note-content-modal');
  modalSection.classList.add('show-modal');
  modalSection.innerHTML = `
        <div class="modal-topbar">
          <button onclick='closeModalNote(event)'><i class="fas fa-chevron-left"></i></button>
          <button><i class="fas fa-edit"></i></button>
        </div>
        <div>
          <input type="text" disabled value="${title}" id="" class="note-title">
          <textarea disabled class="note-content" data-autoresize>${text}</textarea>
        </div>

  `;
  container.appendChild(modalSection);
}