# Responsive Website Restaurant
## [Watch it on youtube](https://youtu.be/5RIFrZEjURA)
### Responsive Website Restaurant
Nice design of a responsive restaurant website 🥗 . It contains a header, home, about, services, menu, app, contact and a footer. It also has a fully developed light/dark mode 🌓 first for mobile then for desktop.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
